# -*- coding: utf-8 -*-
"""
core/problem_locator.py

HWP 문서 내부 컨트롤 구조를 이용한 문제 위치 탐색 및 태그 기반 분류 모듈.
"""

import re
from typing import List, Tuple, Optional, Dict

from core.models import ProblemBlock, ExceptionProblem
from core.difficulty_extractor import extract_difficulty, extract_difficulty_raw, extract_chapter_raw
from config.settings import DIFFICULTY_PATTERN

# 문제 블록 하나로 보기에는 너무 짧은 텍스트(순수 잡음/공백 등)를 걸러내기 위한 최소 글자 수.
# 이 값보다 짧으면 애초에 '문제'로 보지 않고 조용히 건너뜁니다(예외 목록에도 넣지 않음).
_MIN_BLOCK_CHARS = 8

# [난이도] 태그가 두 번 이상 등장하면, 문제 끝 경계를 잘못 잡아
# 다음 문제가 같은 블록에 딸려 들어온(병합된) 것으로 판단합니다.
_DIFFICULTY_TAG_COUNT_PATTERN = re.compile(DIFFICULTY_PATTERN)

# 서술형/서답형 문제의 시작 표제를 찾기 위한 검색 텍스트 목록.
_ESSAY_HEADING_TEXTS = ["[서술형", "[서답형"]

# [난이도] 태그의 실제 위치를 찾기 위한 검색 텍스트.
# (extract 시 사용하는 DIFFICULTY_PATTERN은 텍스트 조각에 대한 정규식이라
#  hwp 상 좌표 검색에는 쓸 수 없으므로, 좌표 검색용 리터럴 문자열을 별도로 둡니다.)
_DIFFICULTY_TAG_SEARCH_TEXT = "[난이도]"


class ProblemLocatorError(Exception):
    pass


class ProblemLocator:

    _AUTO_NUM_CTRL_IDS = {"atno", "nwno"}
    _ENDNOTE_CTRL_ID = "en"

    def __init__(self, logger=None):
        self.logger = logger

    def locate_problems(
        self,
        hwp,
        source_file: str = "",
        valid_chapters: List[str] = None,
    ) -> Tuple[List[ProblemBlock], List[Dict]]:
        """
        문제를 탐색하고 분류합니다.
        """
        # ── 서술형/서답형 표제 위치 검색 ────────────────────────────────
        # 이 위치들은 (1) 서술형 문제 자체의 시작 경계로 쓰이는 동시에,
        # (2) 표제부터 그 문제의 [난이도] 태그까지의 구간(zone) 내부에 있는
        #     자동번호(소문항 번호 등)를 문제 시작 후보에서 제외하는 데도 사용됩니다.
        essay_positions = []
        for text in _ESSAY_HEADING_TEXTS:
            essay_positions.extend(self._find_text_occurrences(hwp, text))
        essay_zones = self._build_essay_zones(hwp, essay_positions)

        boundaries = self._find_problem_start_positions(hwp, source_file, essay_zones)

        # ── 서술형/서답형 텍스트 검색을 통한 추가 경계 감지 ────────────────
        # 자동번호 각주가 없는 서술형 문제들이 이전 문제에 병합되어
        # '경계오류_병합의심'이 발생하는 것을 방지하기 위해 텍스트 위치를 검색해 경계에 추가합니다.
        if essay_positions:
            boundaries.extend(essay_positions)
            # 중복 제거 및 좌표 정렬 (List, Para, Pos 순)
            seen = set()
            unique_boundaries = []
            for b in boundaries:
                key = (b["list"], b["para"], b["pos"])
                if key not in seen:
                    seen.add(key)
                    unique_boundaries.append(b)
            boundaries = unique_boundaries
            boundaries.sort(key=lambda b: (b["list"], b["para"], b["pos"]))

        if not boundaries:
            raise ProblemLocatorError("문제 시작 위치를 찾지 못했습니다.")

        doc_end = self._get_doc_end_position(hwp)
        problems: List[ProblemBlock] = []
        exceptions: List[Dict] = []

        for i, start in enumerate(boundaries):
            end = boundaries[i + 1] if i + 1 < len(boundaries) else doc_end

            try:
                plain_text = self._get_plain_text_between(hwp, start, end)
            except Exception as e:
                self._log_error(f"{i+1}번째 문제 텍스트 추출 실패: {e}", source_file)
                continue

            # ── 잡음 필터: 실제 내용이 거의 없는 블록은 문제로도, 예외로도 다루지 않고 건너뜁니다.
            # (문제 끝 경계가 잘못 잡혀 아주 짧은 조각이 하나의 '문제'처럼 생기는 경우를 방지)
            if len(plain_text.strip()) < _MIN_BLOCK_CHARS:
                continue

            # ── 태그 추출 ──────────────────────────────────────────────────
            # 정교화된 추출 로직 사용
            difficulty = extract_difficulty(plain_text)
            raw_difficulty = extract_difficulty_raw(plain_text)
            raw_chapter = extract_chapter_raw(plain_text)

            coords = {
                "start_list": start["list"],
                "start_para": start["para"],
                "start_pos": start["pos"],
                "end_list": end["list"],
                "end_para": end["para"],
                "end_pos": end["pos"]
            }

            # ── 병합 감지: [난이도] 태그가 2회 이상 등장하면, 문제 끝 경계를
            # 못 찾아서 다음 문제가 이 블록에 같이 딸려 들어온 것으로 판단합니다.
            # 이런 블록은 '난이도/중단원 오류'가 아니라 '경계 오류'이므로 별도 사유로 분리합니다.
            tag_count = len(_DIFFICULTY_TAG_COUNT_PATTERN.findall(plain_text))

            # ── 예외 판별 (요구사항 3 반영: 정상 문제는 절대 예외 처리하지 않음) ──
            reason = None

            if tag_count >= 2:
                reason = "boundary_merge_suspected"
            # 1. 중단원 태그가 아예 없는 경우
            elif not raw_chapter:
                reason = "no_chapter_tag"
            # 2. 중단원이 등록된 목록에 없는 경우
            elif valid_chapters and raw_chapter not in valid_chapters:
                reason = "invalid_chapter"
            # 3. 난이도 태그가 아예 없는 경우
            elif not raw_difficulty:
                reason = "no_difficulty_tag"
            # 4. 난이도가 상/중/하 외의 값인 경우
            elif difficulty is None:
                reason = "invalid_difficulty"

            if reason:
                exc = ExceptionProblem(
                    source_file=source_file, problem_number=str(i + 1),
                    reason=reason, raw_difficulty=raw_difficulty,
                    raw_chapter=raw_chapter, plain_text_preview=plain_text[:400]
                )
                exceptions.append({"exc": exc, "coords": coords})
                continue

            # ── 정상 문제 ──────────────────────────────────────────────────
            # 중단원(raw_chapter)과 난이도(difficulty)가 모두 정상인 경우만 도달
            problems.append(ProblemBlock(
                index=i + 1, problem_number=str(i + 1),
                start_list=coords["start_list"],
                start_para=coords["start_para"],
                start_pos=coords["start_pos"],
                end_list=coords["end_list"],
                end_para=coords["end_para"],
                end_pos=coords["end_pos"],
                plain_text=plain_text, difficulty=difficulty,
                source_file=source_file, chapter=raw_chapter
            ))

        return problems, exceptions

    def _find_problem_start_positions(self, hwp, source_file="", essay_zones=None):
        """
        문제 시작 위치(자동번호 atno/nwno)와, 그 문제에 딸린 각주/미주(en)를 찾아
        '각주가 달린 자동번호'만 진짜 문제 시작으로 인정합니다.

        주의: hwp.ctrl_list가 반환하는 순서는 항상 문서상 실제 위치 순서와
        일치한다는 보장이 없습니다(특히 미주/각주 컨트롤이 본문 컨트롤과 다른
        내부 순서로 열거되는 경우가 있음). 순서가 어긋나면 자동번호와 각주의
        짝이 잘못 맞춰져 '문제 끝을 인식 못하는' 현상이나, 정상 문제가 잡음으로
        빠지는 현상으로 이어집니다. 이를 막기 위해 각 컨트롤의 실제 좌표
        (list, para, pos)를 먼저 구한 뒤, 좌표 기준으로 다시 정렬해서 짝을
        맞춥니다.

        추가 필터(essay_zones): 서술형/서답형 문제는 표제 자동번호뿐 아니라
        본문 안의 소문항(예: (1), (2))에도 자동번호(atno/nwno)와 배점 각주가
        각각 딸려 있습니다. 표제 문단만 걸러내던 예전 방식으로는 이 소문항
        번호들이 '각주 달린 자동번호'로 오인되어 서술형 문제 중간에서 새
        문제가 시작된 것처럼 잘못 쪼개지고, 그 결과 진짜 경계가 밀리면서
        다음 문제와 병합되거나([난이도] 태그 2회 이상 검출) 서술형 문제
        자체가 통째로 유실되는 원인이 됩니다.
        essay_zones는 '[서술형'/'[서답형' 표제부터 그 문제의 [난이도] 태그
        까지의 구간 목록이며, 이 구간에 속한 자동번호는 통째로 무시합니다
        (표제 자체의 경계는 별도의 텍스트 검색으로 이미 추가되므로 문제 없음).
        """
        essay_zones = essay_zones or []

        try:
            controls = list(hwp.ctrl_list)
        except Exception as e:
            self._log_error(f"ctrl_list 접근 실패: {e}", source_file)
            return []

        events = []  # (list, para, pos, kind) — kind: "num" 또는 "note"
        for ctrl in controls:
            try:
                cid = ctrl.CtrlID
            except Exception:
                continue

            if cid in self._AUTO_NUM_CTRL_IDS:
                try:
                    list_id, para, pos = hwp.get_ctrl_pos(ctrl, option=1)
                except Exception:
                    continue
                events.append((list_id, para, pos, "num"))
            elif cid == self._ENDNOTE_CTRL_ID:
                try:
                    list_id, para, pos = hwp.get_ctrl_pos(ctrl, option=1)
                except Exception:
                    # 좌표를 구할 수 없으면 순서 정렬이 불가능하므로
                    # 안전하게 '가장 최근 위치 이후 어딘가'로 간주할 수 없어 건너뜁니다.
                    continue
                events.append((list_id, para, pos, "note"))

        # 문서상 실제 위치 순서로 정렬 (list, para, pos 순)
        events.sort(key=lambda e: (e[0], e[1], e[2]))

        positions = []
        pending = None
        pending_has_endnote = False

        for list_id, para, pos, kind in events:
            coord = (list_id, para, pos)
            in_essay_zone = self._in_zones(coord, essay_zones)

            if kind == "num":
                if pending is not None and pending_has_endnote:
                    if not self._is_noise_position(pending):
                        positions.append(pending)

                # ── 서술형/서답형 구간 필터 ──────────────────────────────
                # 구간 내부의 자동번호(표제 번호 및 소문항 번호 모두)는
                # 문제 시작점으로 등록하지 않습니다. 이렇게 하면 서술형 문제
                # 내부의 소문항 번호가 새 '문제 시작'으로 오인되어 경계가
                # 잘못 쪼개지는 것을 막을 수 있습니다.
                if in_essay_zone:
                    pending = None
                    pending_has_endnote = False
                else:
                    pending = {"list": list_id, "para": para, "pos": pos}
                    pending_has_endnote = False
            else:  # kind == "note"
                if pending is not None and not in_essay_zone:
                    pending_has_endnote = True

        if pending is not None and pending_has_endnote and not self._is_noise_position(pending):
            positions.append(pending)

        return positions

    def _is_noise_position(self, pos):
        return pos["para"] == 0 and pos["pos"] < 20

    def _build_essay_zones(self, hwp, essay_positions: list) -> list:
        """
        essay_positions(각 '[서술형'/'[서답형' 표제 좌표)를 받아, 각 표제부터
        해당 문제의 [난이도] 태그가 나오는 좌표까지의 구간 목록을 만듭니다.
        [난이도] 태그를 찾지 못하면 문서 끝까지를 구간으로 잡습니다(안전한 기본값).
        """
        if not essay_positions:
            return []

        def key(c):
            return (c["list"], c["para"], c["pos"])

        heads = sorted(essay_positions, key=key)
        difficulty_tags = sorted(
            self._find_text_occurrences(hwp, _DIFFICULTY_TAG_SEARCH_TEXT), key=key
        )
        doc_end = key(self._get_doc_end_position(hwp))

        zones = []
        for head in heads:
            head_key = key(head)
            end_key = doc_end
            for tag in difficulty_tags:
                tag_key = key(tag)
                if tag_key > head_key:
                    end_key = tag_key
                    break
            zones.append((head_key, end_key))
        return zones

    def _in_zones(self, coord: tuple, zones: list) -> bool:
        """coord(list, para, pos)가 zones 중 하나의 구간 (start, end] 안에 있는지 확인합니다."""
        for start, end in zones:
            if start < coord <= end:
                return True
        return False

    def _find_text_occurrences(self, hwp, query: str) -> list:
        """
        문서 전체에서 특정 텍스트를 검색하여 좌표 목록을 반환합니다.

        주의: 예전 코드는 `hwp.CreateAction("Find")`를 사용했지만, 한/글
        오토메이션 액션 테이블에는 "Find"라는 액션 ID가 존재하지 않습니다
        (찾기 대화상자를 여는 액션은 "FindDlg", 대화상자 없이 실제 검색을
        실행하는 액션은 "RepeatFind"). 따라서 CreateAction("Find")는 항상
        None을 반환했고, 뒤이은 act.CreateSet() 호출에서
        "'NoneType' object has no attribute 'CreateSet'" 오류가 발생해
        서술형/서답형 표제를 전혀 찾지 못하고 있었습니다(로그의 "텍스트
        '[서술형' 검색 중 오류 발생" 부분). pyhwpx 라이브러리 자체의
        find() 구현과 동일한 방식(GetDefault("FindDlg")로 기본값을 채운 뒤
        Execute("RepeatFind")를 반복 실행)으로 교체합니다.
        """
        occurrences = []
        try:
            pset = hwp.HParameterSet.HFindReplace
            hwp.HAction.GetDefault("FindDlg", pset.HSet)
            pset.FindString = query
            pset.Direction = hwp.FindDir("Forward")
            pset.IgnoreMessage = 1
            pset.MatchCase = 1

            # 찾기 관련 팝업(예: "더 이상 찾을 내용이 없습니다")이 자동화를
            # 멈추지 않도록 메시지박스를 자동 처리 모드로 전환합니다.
            try:
                hwp.SetMessageBoxMode(0x2FFF1)
            except Exception:
                pass

            # 현재 커서 위치 저장
            old_info = hwp.GetPosBySet()
            old_pos = (old_info.Item("List"), old_info.Item("Para"), old_info.Item("Pos"))

            hwp.MoveDocBegin()
            while hwp.HAction.Execute("RepeatFind", pset.HSet):
                info = hwp.GetPosBySet()
                occurrences.append({
                    "list": info.Item("List"),
                    "para": info.Item("Para"),
                    "pos": info.Item("Pos")
                })
                # 검색이 끝난 위치에서 한 글자 우측으로 이동하여 무한 루프 방지
                hwp.HAction.Run("MoveRight")

            # 커서 원위치 복구
            hwp.set_pos(*old_pos)
        except Exception as e:
            if self.logger:
                self.logger.error(f"텍스트 '{query}' 검색 중 오류 발생: {e}")
        finally:
            try:
                hwp.SetMessageBoxMode(0xFFFFF)
            except Exception:
                pass
        return occurrences

    def _get_doc_end_position(self, hwp):
        hwp.MoveDocEnd()
        info = hwp.GetPosBySet()
        return {"list": info.Item("List"), "para": info.Item("Para"), "pos": info.Item("Pos")}

    def _get_plain_text_between(self, hwp, start, end):
        hwp.select_text(start["para"], start["pos"], end["para"], end["pos"], start["list"])
        text = hwp.get_selected_text() or ""
        hwp.Cancel()
        return text

    def _log_error(self, message, source_file=""):
        if self.logger:
            self.logger.error(message, source_file=source_file)
